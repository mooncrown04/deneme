# Cloudstream extensions

This repository contains a collection of extensions for [Cloudstream3](https://github.com/recloudstream/cloudstream)

## Attribution

The gradle plugin and the whole plugin system is **heavily** based on [Aliucord](https://github.com/Aliucord).
*Go use it, it's a great mobile discord client mod!*
